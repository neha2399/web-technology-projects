function validate(){
	let uname=stdreg.uname.value;
	let upwd=stdreg.upwd.value;
	let cupwd=stdreg.cupwd.value;
	let fname=stdreg.fname.value;
	let lname=stdreg.lname.value;
	let uemail=stdreg.uemail.value;
	let ucourse=stdreg.ucourse.selectedIndex;
	let umob=stdreg.umob.value;
	let flag=false;
	let str="";
	let efilter=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	if(uname.trim()==""){
		flag=true;
		str += "usernameis blank\n";
	}
	if(upwd.trim()==""&& cupwd.trim()==""||upwd!=cupwd){
		flag=true;
		str += "password is blank or does not match\n";
	}
	if(fname.trim()==""){
		flag=true;
		str+="firstname is blank\n";
	}
	if(lname.trim()==""){
		flag=true;
		str += "lastname is blank\n";
	}
	
	if(stdreg.gender[0].checked==false&& stdreg.gender[1].checked==false){
		flag=true;
		str += "gender is not selected!!\n"	
	}
	
	if(!efilter.test(uemail)){
		flag=true;
		str += "email is invalid\n";
	}
	if(ucourse==0){
		flag=true;
		str += "select course\n";
	}
	if(umob.length != 10){
		flag=true;
		str += "invalid mobile no";
	}
	if(flag){
		alert("warning!!\n"+str);
		return false;
	}
	return true;
}